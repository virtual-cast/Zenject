using System;
using Zenject;
using System.Collections;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.AddressableAssets;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.ResourceManagement.ResourceLocations;
using UnityEngine.TestTools;

public class TestAddressable : ZenjectIntegrationTestFixture
{
    
    [UnityTest]
    public IEnumerator TestAddressableAsyncLoad()
    {
        PreInstall();
        AsyncOperationHandle<GameObject> handle = default;
        Container.BindAsync<GameObject>().FromMethod(async () =>
        {
            try
            {
                var locationsHandle = Addressables.LoadResourceLocationsAsync("TestAddressablePrefab");
                await locationsHandle.Task;
                Assert.Greater(locationsHandle.Result.Count, 0, "Key required for test is not configured. Check Readme.txt in addressable test folder");

                IResourceLocation location = locationsHandle.Result[0];
                handle = Addressables.LoadAsset<GameObject>(location);
                await handle.Task;
                return handle.Result;
            }
            catch (InvalidKeyException)
            {
                
            }
            return null;
        }).AsCached();
        PostInstall();

        yield return null;
            
        AsyncInject<GameObject> asycFoo = Container.Resolve<AsyncInject<GameObject>>();

        int frameCounter = 0;
        while (!asycFoo.HasResult && !asycFoo.IsFaulted)
        {
            frameCounter++;
            if (frameCounter > 10000)
            {
                Addressables.Release(handle);
                Assert.Fail();
            }
            yield return null;    
        }
            
        Addressables.Release(handle);
        Assert.Pass();
    }
    
}