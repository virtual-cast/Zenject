Create a GameObject prefab and add it to addressable with id "TestAddressablePrefab". This id is used in test. Unfortunately we cannot distribute this with package.

Add Addressables and ResourceManager references to the test assembly definition.